/* 6(c) - Develop a Shopping Cart using a Stateful Session Bean */

// 06c_ShopCartClient.java
package servlet;

import ejpracts.ShopCartStatefulBean;
import java.io.IOException;
import java.io.PrintWriter;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ShopCartClient")
public class ShopCartClient extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            HttpSession s = request.getSession();
            ShopCartStatefulBean cart = (ShopCartStatefulBean) s.getAttribute("cart");
            if (cart == null) {
                try {
                    cart = (ShopCartStatefulBean) new InitialContext().lookup("java:module/ShopCartStatefulBean");
                } catch (NamingException e) {
                    throw new ServletException(e);
                }
                cart.initialize(request.getParameter("user"));
                s.setAttribute("cart", cart);
            }
            String book = request.getParameter("book");
            if (book != null && !book.isEmpty()) {
                cart.addBook(book);
            }
            out.println("<h3>Your Cart</h3><ul>");
            for (String item : cart.getContents()) {
                out.println("<li>" + item + "</li>");
            }
            out.println("</ul>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
}


// 06c_ShopCartStatefulBean.java
package ejpracts;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Remove;
import javax.ejb.Stateful;

@Stateful
class ShopCartStatefulBean {

    private static final String URL =
        "jdbc:mysql://localhost:3306/reg?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private final List<String> items = new ArrayList<>();
    private String userName;

    public void initialize(String user) {
        this.userName = user;
    }

    public void addBook(String title) {
        items.add(title);
        try (Connection con = DriverManager.getConnection(URL, "root", "root");
             PreparedStatement ps = con.prepareStatement("INSERT INTO mycart VALUES (?, ?)")) {
            ps.setString(1, userName);
            ps.setString(2, title);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void removeProduct(String title) {
        items.remove(title);
    }

    public List<String> getContents() {
        return items;
    }

    @Remove
    public void remove() {
        items.clear();
    }
}


/* 06c_cart.html
<!DOCTYPE html>
<html>
<head><title>Shopping Cart</title></head>
<body>
  <h2>Shopping Cart</h2>
  <form action="ShopCartClient" method="post">
    User: <input name="user"/><br/>
    Book: <input name="book"/><br/>
    <input type="submit" value="Add to Cart"/>
  </form>
</body>
</html>
*/


/* 06c_database.sql
USE reg;
CREATE TABLE IF NOT EXISTS mycart (username VARCHAR(60), item VARCHAR(200));
*/
