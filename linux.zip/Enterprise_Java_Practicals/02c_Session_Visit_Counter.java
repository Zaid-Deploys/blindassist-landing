/* 2(c) - Create Servlets demonstrating Sessions and checking previous visits */

// 02c_SessionCounter.java
package ejpracts;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SessionCounter")
public class SessionCounter extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            HttpSession mysession = request.getSession(true);
            Integer visitCount = (Integer) mysession.getAttribute("sessionVisit");
            if (mysession.isNew() || visitCount == null) {
                visitCount = 1;
            } else {
                visitCount = visitCount + 1;
            }
            mysession.setAttribute("sessionVisit", visitCount);
            out.println("<html><head><title>Visit Counter</title></head><body>");
            out.println("<h3>You have visited this page <b>" + visitCount + "</b> time(s) this session.</h3>");
            out.println("<p>Your Session ID is: <b>" + mysession.getId() + "</b></p>");
            out.println("<a href='SessionEnd'>End The Session</a>");
            out.println("</body></html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
}


// 02c_SessionEnd.java
package ejpracts;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SessionEnd")
class SessionEnd extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            HttpSession session = request.getSession(false);
            if (session != null) {
                out.println("<h3>" + session.getAttribute("sessionVisit") + " times you visited before this session ended.</h3>");
                session.invalidate();
            } else {
                out.println("<h3>No active session found.</h3>");
            }
            out.println("<br/><a href='SessionCounter'>Click Here to Start New Session</a>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
}


/* 02c_index.html
<!DOCTYPE html>
<html>
<head><title>Session Counter</title></head>
<body>
  <h2>Session Visit Counter</h2>
  <p><a href="SessionCounter">Open the session counter</a></p>
</body>
</html>
*/
