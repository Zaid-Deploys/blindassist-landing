/* 6(a) - Create a Currency Converter application using EJB */

// 06a_CCBean.java
package ejpracts;

import java.math.BigDecimal;
import java.math.RoundingMode;
import javax.ejb.Stateless;

@Stateless
public class CCBean {

    private final BigDecimal inrRate = new BigDecimal("83.25");
    private final BigDecimal dollarRate = new BigDecimal("0.012");

    public BigDecimal convert(String from, String to, BigDecimal amount) {
        if (from.equalsIgnoreCase(to)) {
            return amount;
        }
        if (from.equalsIgnoreCase("dollar") && to.equalsIgnoreCase("inr")) {
            return amount.multiply(inrRate).setScale(2, RoundingMode.HALF_UP);
        } else if (from.equalsIgnoreCase("inr") && to.equalsIgnoreCase("dollar")) {
            return amount.multiply(dollarRate).setScale(2, RoundingMode.HALF_UP);
        }
        return amount;
    }
}


// 06a_CCClient.java
package servlet;

import ejpracts.CCBean;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CCClient")
class CCClient extends HttpServlet {

    @EJB
    private CCBean ccbean;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            BigDecimal amt = new BigDecimal(request.getParameter("amt"));
            String from = request.getParameter("FromC");
            String to = request.getParameter("TOC");
            BigDecimal result = ccbean.convert(from, to, amt);
            out.println("<h3>Conversion Result:</h3>");
            out.println("<p>" + amt + " " + from + " = <b>" + result + " " + to + "</b></p>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
}


/* 06a_index.html
<!DOCTYPE html>
<html>
<head><title>Currency Converter</title></head>
<body>
  <h2>Currency Converter</h2>
  <form action="CCClient" method="post">
    Amount: <input name="amt"/><br/><br/>
    From: <select name="FromC"><option>dollar</option><option>inr</option></select>
    To: <select name="TOC"><option>inr</option><option>dollar</option></select><br/><br/>
    <input type="submit" value="Convert"/>
  </form>
</body>
</html>
*/
