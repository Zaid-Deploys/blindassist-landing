/* 2(b) - Create a Servlet using Cookies to count user visits */

// 02b_CookieCounter.java
package ejpracts;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CookieCounter")
public class CookieCounter extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            int count = 1;
            Cookie[] cookies = request.getCookies();
            if (cookies != null) {
                for (Cookie ck : cookies) {
                    if ("noOfVisit".equals(ck.getName())) {
                        count = Integer.parseInt(ck.getValue()) + 1;
                    }
                }
            }
            Cookie myCookie = new Cookie("noOfVisit", String.valueOf(count));
            myCookie.setMaxAge(60 * 60 * 24 * 30); // 30 days
            response.addCookie(myCookie);
            if (count == 1) {
                out.println("<h2>Welcome, this is your first visit!</h2>");
            } else {
                out.println("<h2>You visited <b>" + count + "</b> times</h2>");
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
}


/* 02b_index.html
<!DOCTYPE html>
<html>
<head><title>Cookie Counter</title></head>
<body>
  <h2>Cookie Visit Counter</h2>
  <p><a href="CookieCounter">Open the counter</a></p>
</body>
</html>
*/
