/* 3(a) - Create a Servlet application to upload and download files */

// 03a_DownServ.java
package ejpracts;

import java.io.IOException;
import java.io.InputStream;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DownServ")
public class DownServ extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String fileName = request.getParameter("file");
        ServletContext context = getServletContext();
        InputStream is = context.getResourceAsStream("/" + fileName);
        if (is == null) {
            response.setContentType("text/html;charset=UTF-8");
            response.getWriter().println("File not found: " + fileName);
            return;
        }
        String mime = context.getMimeType(fileName);
        response.setContentType(mime != null ? mime : "application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
        try (ServletOutputStream os = response.getOutputStream()) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = is.read(buffer)) != -1) {
                os.write(buffer, 0, bytesRead);
            }
            os.flush();
        } finally {
            is.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
}


// 03a_UpServ.java
package ejpracts;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/UpServ")
@MultipartConfig
class UpServ extends HttpServlet {

    private String getFileName(final Part part) {
        String header = part.getHeader("content-disposition");
        for (String content : header.split(";")) {
            if (content.trim().startsWith("filename")) {
                return content.substring(content.indexOf('=') + 1).trim().replace("\"", "");
            }
        }
        return null;
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String path = request.getParameter("folder");
        Part filePart = request.getPart("upfile");
        String fileName = getFileName(filePart);
        File dir = new File(path);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        try (OutputStream out1 = new FileOutputStream(new File(dir, fileName));
             InputStream filecontent = filePart.getInputStream()) {
            byte[] bytes = new byte[4096];
            int read;
            while ((read = filecontent.read(bytes)) != -1) {
                out1.write(bytes, 0, read);
            }
            response.getWriter().println("<h3>File '" + fileName + "' uploaded successfully to " + path + "</h3>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
}


/* 03a_upload.html
<!DOCTYPE html>
<html>
<head><title>File Upload</title></head>
<body>
  <h2>File Upload</h2>
  <form action="UpServ" method="post" enctype="multipart/form-data">
    Target folder (absolute path): <input name="folder" value="C:\uploads"/><br/><br/>
    Choose file: <input name="upfile" type="file"/><br/><br/>
    <input type="submit" value="Upload"/>
  </form>
  <p>Download example: <a href="DownServ?file=sample.txt">DownServ?file=sample.txt</a><br/>
  (Put sample.txt in the Web Pages folder first.)</p>
</body>
</html>
*/
