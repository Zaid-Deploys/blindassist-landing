<%-- 5(b) - Demonstrate Expression Language (EL) in JSP --%>

<%-- 05b_show.jsp --%>
<%@ page contentType="text/html; charset=UTF-8" %>
<% pageContext.setAttribute("colour", "#e6f7ff");
   application.setAttribute("author", "ejava prac");
   session.setAttribute("country", "India"); %>
<!DOCTYPE html>
<html>
<head><title>EL Demonstration</title></head>
<body style="background-color:${pageScope.colour};">
  <h3>Welcome ${param.ufname} ${param.ulname}</h3>
  <p>Author Name (Application Scope): <b>${applicationScope.author}</b></p>
  <p>Author Country (Session Scope): <b>${sessionScope.country}</b></p>
  <h4>EL Relational Comparisons:</h4>
  <p>Is 1 &lt; 2? <b>${1 lt 2}</b><br/>
     Does 5 equal 5? <b>${5 == 5}</b><br/>
     Is 6 &gt; 7? <b>${6 gt 7}</b></p>
  <h4>EL Arithmetic:</h4>
  <p>6 + 7 = <b>${6 + 7}</b><br/> 8 * 9 = <b>${8 * 9}</b></p>
  <p>Browser Header: <i>${header["user-agent"]}</i></p>
</body>
</html>
