/* 9(a) - Develop a JPA application demonstrating ORM associations */

// 09a_Author.java
package ormapp;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "orm_author")
public class Author implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer authorId;
    private String authorName;

    // One Author -> Many Books (the "many" side owns the foreign key)
    @OneToMany(mappedBy = "author", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<OrmBook> books = new ArrayList<>();

    public Integer getAuthorId() { return authorId; }
    public void setAuthorId(Integer authorId) { this.authorId = authorId; }
    public String getAuthorName() { return authorName; }
    public void setAuthorName(String authorName) { this.authorName = authorName; }
    public List<OrmBook> getBooks() { return books; }
    public void setBooks(List<OrmBook> books) { this.books = books; }
}


// 09a_OrmBook.java
package ormapp;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "orm_book")
class OrmBook implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer bookId;
    private String title;

    // Many Books -> One Author
    @ManyToOne
    @JoinColumn(name = "author_id")
    private Author author;

    public Integer getBookId() { return bookId; }
    public void setBookId(Integer bookId) { this.bookId = bookId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public Author getAuthor() { return author; }
    public void setAuthor(Author author) { this.author = author; }
}


/* 09a_authors.jsp
<%@ page import="javax.persistence.*, ormapp.Author, ormapp.OrmBook, java.util.List" contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%
   EntityManagerFactory emf = Persistence.createEntityManagerFactory("ORMPU");
   EntityManager em = emf.createEntityManager();
   if (request.getParameter("addAuthor") != null) {
     em.getTransaction().begin();
     Author a = new Author();
     a.setAuthorName(request.getParameter("aname"));
     em.persist(a);
     em.getTransaction().commit();
   }
   if (request.getParameter("addBook") != null) {
     em.getTransaction().begin();
     Author a = em.find(Author.class, Integer.parseInt(request.getParameter("authorId")));
     OrmBook b = new OrmBook();
     b.setTitle(request.getParameter("btitle"));
     b.setAuthor(a);
     em.persist(b);
     em.getTransaction().commit();
   }
   request.setAttribute("authors", em.createQuery("SELECT a FROM Author a", Author.class).getResultList());
   em.close();
   emf.close();
%>
<html><body>
<h2>ORM Associations: Author (One) - Book (Many)</h2>
<form method="post">
  Author Name: <input name="aname"/>
  <input type="submit" name="addAuthor" value="Add Author"/>
</form>
<form method="post">
  Author No: <input name="authorId"/> Book Title: <input name="btitle"/>
  <input type="submit" name="addBook" value="Add Book for Author"/>
</form>
<c:forEach items="${authors}" var="a">
  <h3>Author ${a.authorId}: ${a.authorName}</h3>
  <ul>
    <c:forEach items="${a.books}" var="b">
      <li>${b.title}</li>
    </c:forEach>
  </ul>
</c:forEach>
</body></html>
*/

/* 09a_persistence.xml
<?xml version="1.0" encoding="UTF-8"?>
<persistence version="2.1" xmlns="http://xmlns.jcp.org/xml/ns/persistence">
  <persistence-unit name="ORMPU" transaction-type="RESOURCE_LOCAL">
    <provider>org.eclipse.persistence.jpa.PersistenceProvider</provider>
    <class>ormapp.Author</class>
    <class>ormapp.OrmBook</class>
    <exclude-unlisted-classes>true</exclude-unlisted-classes>
    <properties>
      <property name="javax.persistence.jdbc.driver" value="com.mysql.cj.jdbc.Driver"/>
      <property name="javax.persistence.jdbc.url" value="jdbc:mysql://localhost:3306/reg?useSSL=false&amp;allowPublicKeyRetrieval=true&amp;serverTimezone=UTC"/>
      <property name="javax.persistence.jdbc.user" value="root"/>
      <property name="javax.persistence.jdbc.password" value="root"/>
      <property name="eclipselink.ddl-generation" value="create-or-extend-tables"/>
    </properties>
  </persistence-unit>
</persistence>
*/
