/* 8(c) - Create a JPA application to store and retrieve Book details */

// 08c_Book.java
package mybook;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "book")
public class Book implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer bookNo;
    private String isbn;
    private String bookTitle;
    private String author;
    private String edition;
    private String pYear;
    private String publisher;
    private String quantity;

    public Integer getBookNo() { return bookNo; }
    public void setBookNo(Integer b) { this.bookNo = b; }
    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
    public String getBookTitle() { return bookTitle; }
    public void setBookTitle(String t) { this.bookTitle = t; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    public String getEdition() { return edition; }
    public void setEdition(String edition) { this.edition = edition; }
    public String getpYear() { return pYear; }
    public void setpYear(String pYear) { this.pYear = pYear; }
    public String getPublisher() { return publisher; }
    public void setPublisher(String publisher) { this.publisher = publisher; }
    public String getQuantity() { return quantity; }
    public void setQuantity(String quantity) { this.quantity = quantity; }
}


/* 08c_books.jsp
<%@ page import="javax.persistence.*, mybook.Book, java.util.List" contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%
   EntityManagerFactory emf = Persistence.createEntityManagerFactory("BOOKPU");
   EntityManager em = emf.createEntityManager();
   if (request.getParameter("add") != null) {
     em.getTransaction().begin();
     Book b = new Book();
     b.setIsbn(request.getParameter("isbn"));
     b.setBookTitle(request.getParameter("title"));
     b.setAuthor(request.getParameter("author"));
     b.setEdition(request.getParameter("edition"));
     b.setpYear(request.getParameter("year"));
     b.setPublisher(request.getParameter("publisher"));
     b.setQuantity(request.getParameter("qty"));
     em.persist(b);
     em.getTransaction().commit();
   }
   request.setAttribute("books", em.createQuery("SELECT b FROM Book b", Book.class).getResultList());
   em.close();
   emf.close();
%>
<html><body>
<h2>Book Inventory</h2>
<form method="post">
   ISBN: <input name="isbn"/> Title: <input name="title"/> Author: <input name="author"/><br/>
   Edition: <input name="edition"/> Year: <input name="year"/> Publisher: <input name="publisher"/>
   Qty: <input name="qty"/> <input type="submit" name="add" value="Add Book"/>
</form>
<table border="1">
   <tr><th>No</th><th>ISBN</th><th>Title</th><th>Author</th><th>Qty</th></tr>
   <c:forEach items="${books}" var="b">
     <tr><td>${b.bookNo}</td><td>${b.isbn}</td><td>${b.bookTitle}</td><td>${b.author}</td><td>${b.quantity}</td></tr>
   </c:forEach>
</table>
</body></html>
*/

/* 08c_persistence.xml
<?xml version="1.0" encoding="UTF-8"?>
<persistence version="2.1" xmlns="http://xmlns.jcp.org/xml/ns/persistence">
  <persistence-unit name="BOOKPU" transaction-type="RESOURCE_LOCAL">
    <provider>org.eclipse.persistence.jpa.PersistenceProvider</provider>
    <class>mybook.Book</class>
    <exclude-unlisted-classes>true</exclude-unlisted-classes>
    <properties>
      <property name="javax.persistence.jdbc.driver" value="com.mysql.cj.jdbc.Driver"/>
      <property name="javax.persistence.jdbc.url" value="jdbc:mysql://localhost:3306/reg?useSSL=false&amp;allowPublicKeyRetrieval=true&amp;serverTimezone=UTC"/>
      <property name="javax.persistence.jdbc.user" value="root"/>
      <property name="javax.persistence.jdbc.password" value="root"/>
      <property name="eclipselink.ddl-generation" value="create-or-extend-tables"/>
    </properties>
  </persistence-unit>
</persistence>
*/
