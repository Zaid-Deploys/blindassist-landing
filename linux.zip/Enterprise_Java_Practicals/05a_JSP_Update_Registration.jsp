<%-- 5(a) - Create a JSP application to update user registration details in a database --%>

<%-- 05a_update.html
<!DOCTYPE html>
<html>
<head><title>Update Registration</title></head>
<body>
  <h2>Update Registration Details</h2>
  <form action="updateDetails.jsp" method="post">
    UID: <input name="uid"/><br/>
    First Name: <input name="fname"/><br/>
    Surname: <input name="sname"/><br/>
    Password: <input name="pwd" type="password"/><br/>
    Town: <input name="town"/><br/>
    Country: <input name="country"/><br/>
    Zip: <input name="zip"/><br/>
    <input type="submit" value="Update"/>
  </form>
</body>
</html>
--%>


<%-- 05a_updateDetails.jsp --%>
<%@ page import="java.sql.*" contentType="text/html; charset=UTF-8" %>
<%
   String uid = request.getParameter("uid");
   String url = "jdbc:mysql://localhost:3306/reg?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
   String sql = "UPDATE register SET fname=?, sname=?, pwd=?, town=?, country=?, zipcode=? WHERE uid=?";
   try {
     Class.forName("com.mysql.cj.jdbc.Driver");
     try (Connection con = DriverManager.getConnection(url, "root", "root");
          PreparedStatement pst = con.prepareStatement(sql)) {
       pst.setString(1, request.getParameter("fname"));
       pst.setString(2, request.getParameter("sname"));
       pst.setString(3, request.getParameter("pwd"));
       pst.setString(4, request.getParameter("town"));
       pst.setString(5, request.getParameter("country"));
       pst.setString(6, request.getParameter("zip"));
       pst.setString(7, uid);
       int rows = pst.executeUpdate();
       out.println(rows > 0 ? "<h3>Record successfully updated!</h3>" : "<h3>No matching UID found.</h3>");
     }
   } catch (Exception e) {
     out.println("<h3>Error: " + e.getMessage() + "</h3>");
   }
%>
