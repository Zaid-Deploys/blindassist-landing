<%-- 4(a) - Develop a JSP application using implicit objects --%>

<%-- 04a_implicit.jsp --%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head><title>JSP Implicit Objects</title></head>
<body>
  <h2>JSP Implicit Objects Demonstration</h2>
  <p><b>Request Locale:</b> <%= request.getLocale() %></p>
  <p><b>Out Object:</b> <% out.print("Rendered via out.print()"); %></p>
  <p><b>Servlet Config Name:</b> <%= config.getServletName() %></p>
  <p><b>Application Server Info:</b> <%= application.getServerInfo() %></p>
  <p><b>Page Class Name:</b> <%= this.getClass().getName() %></p>
  <p><b>Session Creation Time:</b> <%= session.getCreationTime() %></p>
  <% pageContext.setAttribute("Practical", "Enterprise Java"); %>
  <p><b>PageContext Attribute:</b> <%= pageContext.getAttribute("Practical") %></p>
</body>
</html>
