/* 7(c) - Develop a Marks Entry application demonstrating database access using EJB */

// 07c_MarksEntryBean.java
package ejpracts;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.ejb.Stateful;

@Stateful
public class MarksEntryBean {

    private static final String URL =
        "jdbc:mysql://localhost:3306/reg?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

    public void addMarks(String stuname, String m1, String m2, String m3) {
        String sql = "INSERT INTO marks(stuName,sub1,sub2,sub3) VALUES (?,?,?,?)";
        try (Connection con = DriverManager.getConnection(URL, "root", "root");
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, stuname);
            ps.setString(2, m1);
            ps.setString(3, m2);
            ps.setString(4, m3);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


// 07c_MarksServlet.java
package servlet;

import ejpracts.MarksEntryBean;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/MarksServlet")
class MarksServlet extends HttpServlet {

    @EJB
    private MarksEntryBean bean;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String name = request.getParameter("stuname");
            bean.addMarks(name, request.getParameter("m1"), request.getParameter("m2"), request.getParameter("m3"));
            out.println("<h3>Marks of " + name + " saved successfully.</h3>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
}


/* 07c_database.sql
USE reg;
CREATE TABLE IF NOT EXISTS marks (stuName VARCHAR(60), sub1 VARCHAR(10), sub2 VARCHAR(10), sub3 VARCHAR(10));
*/


/* 07c_marks.html
<!DOCTYPE html>
<html>
<head><title>Marks Entry</title></head>
<body>
  <h2>Student Marks Entry</h2>
  <form action="MarksServlet" method="post">
    Student Name: <input name="stuname"/><br/>
    Subject 1: <input name="m1"/><br/>
    Subject 2: <input name="m2"/><br/>
    Subject 3: <input name="m3"/><br/>
    <input type="submit" value="Save Marks"/>
  </form>
</body>
</html>
*/
