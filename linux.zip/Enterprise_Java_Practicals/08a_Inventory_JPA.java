/* 8(a) - Develop an Inventory Application using JPA */

// 08a_Inventory.java
package myapp;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "inventory")
public class Inventory implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "itemid")
    private Integer itemid;

    @Column(name = "itemName")
    private String itemName;

    @Column(name = "description")
    private String description;

    @Column(name = "quantity")
    private Integer quantity;

    @Column(name = "addedDate")
    private String addedDate;

    public Integer getItemID() { return itemid; }
    public void setItemID(Integer id) { this.itemid = id; }
    public String getItemName() { return itemName; }
    public void setItemName(String n) { this.itemName = n; }
    public String getDescription() { return description; }
    public void setDescription(String d) { this.description = d; }
    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer q) { this.quantity = q; }
    public String getAddedDate() { return addedDate; }
    public void setAddedDate(String dt) { this.addedDate = dt; }
}


/* 08a_checkInventory.jsp
<%@page import="java.util.Iterator, java.util.List, myapp.Inventory,
     javax.persistence.Persistence, javax.persistence.EntityManager,
     javax.persistence.EntityManagerFactory, javax.persistence.EntityTransaction" %>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
   EntityManagerFactory eMF = Persistence.createEntityManagerFactory("INVJPAPU");
   EntityManager eM = eMF.createEntityManager();
   String submit = request.getParameter("AddToInventory");
   if (submit != null && "AddToInventory".equals(submit)) {
     EntityTransaction eT = null;
     try {
       String itemname = request.getParameter("itemname");
       String description = request.getParameter("description");
       int quantity = Integer.parseInt(request.getParameter("quantity"));
       String addedDate = new java.util.Date().toString();
       Inventory item = new Inventory();
       item.setItemName(itemname);
       item.setDescription(description);
       item.setQuantity(quantity);
       item.setAddedDate(addedDate);
       eT = eM.getTransaction();
       eT.begin();
       eM.persist(item);
       eT.commit();
     } catch (RuntimeException e) {
       if (eT != null && eT.isActive()) eT.rollback();
       throw e;
     } finally {
       eM.close();
       eMF.close();
     }
     response.sendRedirect("checkInventory.jsp");
     return;
   }
   List<Inventory> inv = eM.createQuery("SELECT i FROM Inventory i", Inventory.class).getResultList();
   eM.close();
   eMF.close();
%>
<!DOCTYPE html>
<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   <title>Inventory</title>
</head>
<body>
<table border="1" align="center">
   <tr><td colspan="5" align="center">
        <b>Click <a href="index.jsp">here</a> to add items in the Inventory.</b>
   </td></tr>
   <tr><td>Item No</td><td>Item Name</td><td>Description</td>
        <td>Quantity</td><td>Added Date &amp; Time</td></tr>
<%
   Iterator iterator = inv.iterator();
   while (iterator.hasNext()) {
     Inventory objInv = (Inventory) iterator.next();
%>
   <tr>
     <td><b><%= objInv.getItemID() %></b></td>
     <td><b><%= objInv.getItemName() %></b></td>
     <td><b><%= objInv.getDescription() %></b></td>
     <td><b><%= objInv.getQuantity() %></b></td>
     <td><b><%= objInv.getAddedDate() %></b></td>
   </tr>
<%
   }
%>
</table>
</body>
</html>


<%-- 08a_index.jsp --%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <title>Inventory</title>
</head>
<body>
<form action="checkInventory.jsp" method="post">
<table>
  <tr><td colspan="2" align="center"><b>Add the item in Inventory</b></td></tr>
  <tr><td>Item Name: </td>
       <td><input name="itemname" maxlength="25" size="50" /></td></tr>
  <tr><td>Description: </td>
       <td><textarea rows="5" cols="36" name="description"></textarea></td></tr>
  <tr><td>Quantity: </td>
       <td><input name="quantity" maxlength="4" size="5" /></td></tr>
  <tr><td colspan="2">
       <input type="submit" name="AddToInventory" value="AddToInventory" />
  </td></tr>
</table>
</form>
</body>
</html>
*/

/* 08a_persistence.xml
<?xml version="1.0" encoding="UTF-8"?>
<persistence version="2.1" xmlns="http://xmlns.jcp.org/xml/ns/persistence">
  <persistence-unit name="INVJPAPU" transaction-type="RESOURCE_LOCAL">
    <provider>org.eclipse.persistence.jpa.PersistenceProvider</provider>
    <class>myapp.Inventory</class>
    <exclude-unlisted-classes>true</exclude-unlisted-classes>
    <properties>
      <property name="javax.persistence.jdbc.driver" value="com.mysql.cj.jdbc.Driver"/>
      <property name="javax.persistence.jdbc.url" value="jdbc:mysql://localhost:3306/reg?useSSL=false&amp;allowPublicKeyRetrieval=true&amp;serverTimezone=UTC"/>
      <property name="javax.persistence.jdbc.user" value="root"/>
      <property name="javax.persistence.jdbc.password" value="root"/>
      <property name="eclipselink.ddl-generation" value="create-or-extend-tables"/>
    </properties>
  </persistence-unit>
</persistence>
*/
