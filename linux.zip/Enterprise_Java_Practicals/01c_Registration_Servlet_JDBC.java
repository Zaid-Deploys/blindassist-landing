/* 1(c) - Create a registration Servlet using JDBC */

// 01c_TRegistration.java
package ejpracts;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/TRegistration")
public class TRegistration extends HttpServlet {

    private static final String URL =
        "jdbc:mysql://localhost:3306/reg?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String uid = request.getParameter("uid");
            String fname = request.getParameter("fname");
            String sname = request.getParameter("sname");
            String pwd = request.getParameter("pwd");
            String pwd1 = request.getParameter("pwd1");
            String town = request.getParameter("town");
            String country = request.getParameter("country");
            String zipcode = request.getParameter("zip");
            String sql = "INSERT INTO register VALUES (?,?,?,?,?,?,?,?)";
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                try (Connection con = DriverManager.getConnection(URL, "root", "root");
                     PreparedStatement pst = con.prepareStatement(sql)) {
                    pst.setString(1, uid);
                    pst.setString(2, fname);
                    pst.setString(3, sname);
                    pst.setString(4, pwd);
                    pst.setString(5, pwd1);
                    pst.setString(6, town);
                    pst.setString(7, country);
                    pst.setString(8, zipcode);
                    pst.executeUpdate();
                    out.println("<h1>Welcome: '" + fname + "'</h1>");
                }
            } catch (ClassNotFoundException | SQLException e) {
                out.println("<h3>Registration failed: " + e.getMessage() + "</h3>");
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
}


/* 01c_database.sql
CREATE DATABASE IF NOT EXISTS reg;
USE reg;
CREATE TABLE IF NOT EXISTS register (
   uid     VARCHAR(40) PRIMARY KEY,
   fname   VARCHAR(40),
   sname   VARCHAR(40),
   pwd     VARCHAR(40),
   pwd1    VARCHAR(40),
   town    VARCHAR(40),
   country VARCHAR(40),
   zipcode VARCHAR(40)
);
*/


/* 01c_registration.html
<!DOCTYPE html>
<html>
<head><title>Registration</title></head>
<body>
  <h2>Registration</h2>
  <form action="TRegistration" method="post">
    UID: <input name="uid"/><br/>
    First Name: <input name="fname"/><br/>
    Surname: <input name="sname"/><br/>
    Password: <input name="pwd" type="password"/><br/>
    Confirm Password: <input name="pwd1" type="password"/><br/>
    Town: <input name="town"/><br/>
    Country: <input name="country"/><br/>
    Zip: <input name="zip"/><br/>
    <input type="submit" value="Register"/>
  </form>
</body>
</html>
*/
