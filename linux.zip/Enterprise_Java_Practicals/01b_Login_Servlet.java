/* 1(b) - Create a Servlet for a login page */

// 01b_Login.java
package ejpracts;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Login")
public class Login extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String uname = request.getParameter("uname");
            String pass = request.getParameter("pass");
            if ("Tushar".equals(uname) && "Sambare".equals(pass)) {
                out.println("<h2>Hello <b>" + uname + "</b> Welcome to Java Servlet</h2>");
            } else {
                out.println("<h2 style='color:red;'>Login Failed</h2>");
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
}


/* 01b_index.html
<!DOCTYPE html>
<html>
<head><title>Login</title></head>
<body>
  <h2>Login</h2>
  <form action="Login" method="get">
    Enter Username: <input name="uname" type="text"/><br/><br/>
    Enter Password: <input name="pass" type="password"/><br/><br/>
    <input type="submit" value="Login"/>
    <input type="reset" value="Reset"/>
  </form>
</body>
</html>
*/
