/* 7(b) - Develop a Visitor Statistics application using Message Driven and Stateless Session Beans */

// 07b_MsgDrvnBean.java
package ejpracts;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.EJB;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

@MessageDriven(activationConfig = {
    @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
    @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "jms/Queue")
})
public class MsgDrvnBean implements MessageListener {

    @EJB
    private VStatelessBean vs;

    @Override
    public void onMessage(Message message) {
        try {
            if (message instanceof TextMessage) {
                vs.addVisitor(((TextMessage) message).getText());
            }
        } catch (JMSException e) {
            e.printStackTrace();
        }
    }
}


// 07b_VStatelessBean.java
package ejpracts;

import javax.ejb.Stateless;

@Stateless
class VStatelessBean {

    public void addVisitor(String ip) {
        System.out.println("Visitor recorded: " + ip);
    }
}


// 07b_VisitorServlet.java
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.annotation.Resource;
import javax.inject.Inject;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.Queue;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/VisitorServlet")
class VisitorServlet extends HttpServlet {

    @Inject
    @JMSConnectionFactory("jms/__defaultConnectionFactory")
    private JMSContext context;

    @Resource(lookup = "jms/Queue")
    private Queue queue;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            context.createProducer().send(queue, request.getRemoteAddr());
            out.println("<h3>Visitor message sent to the queue: " + request.getRemoteAddr() + "</h3>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
}


/* 07b_index.html
<!DOCTYPE html>
<html>
<head><title>Visitor Statistics</title></head>
<body>
  <h2>Visitor Statistics</h2>
  <p><a href="VisitorServlet">Record a visit</a></p>
</body>
</html>
*/
