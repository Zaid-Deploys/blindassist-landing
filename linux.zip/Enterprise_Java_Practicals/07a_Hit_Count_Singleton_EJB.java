/* 7(a) - Demonstrate Servlet hit count using a Singleton Session Bean */

// 07a_HitServlet.java
package servlet;

import ejpracts.STHitCountBean;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/HitServlet")
public class HitServlet extends HttpServlet {

    @EJB
    private STHitCountBean hits;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<h2>This page has been visited <b>" + hits.incrHitCount() + "</b> times.</h2>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
}


// 07a_STHitCountBean.java
package ejpracts;

import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Singleton;

@Singleton
class STHitCountBean {

    private int count = 0;

    @Lock(LockType.WRITE)
    public int incrHitCount() {
        return ++count;
    }
}


/* 07a_index.html
<!DOCTYPE html>
<html>
<head><title>Hit Counter</title></head>
<body>
  <h2>Hit Counter</h2>
  <p><a href="HitServlet">Open the hit counter</a></p>
</body>
</html>
*/
