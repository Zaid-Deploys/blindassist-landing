/* 6(b) - Develop a Room Reservation System using EJB */

// 06b_ReservationBean.java
package ejpracts;

import java.util.ArrayList;
import javax.ejb.Stateless;

@Stateless
public class ReservationBean {

    public String welcome(String name) {
        return "Hello " + name.toUpperCase() + ", Welcome to Our Hotel!";
    }

    public String payment(String roomtype) {
        if ("SUITE".equalsIgnoreCase(roomtype)) {
            return "You have to pay: Rs. 8000";
        }
        if ("DELUXE".equalsIgnoreCase(roomtype)) {
            return "You have to pay: Rs. 4000";
        }
        return "You have to pay: Rs. 2000";
    }

    public ArrayList<String> reserve(String cname, String add, String ph, String in,
                                     String out, String type, String mode) {
        ArrayList<String> list = new ArrayList<>();
        list.add(cname);
        list.add(add);
        list.add(ph);
        list.add(in);
        list.add(out);
        list.add(type);
        list.add(mode);
        return list;
    }
}


// 06b_ReservationClient.java
package servlet;

import ejpracts.ReservationBean;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ReservationClient")
class ReservationClient extends HttpServlet {

    @EJB
    private ReservationBean rb;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String name = request.getParameter("cname");
            String type = request.getParameter("type");
            out.println("<h3>" + rb.welcome(name) + "</h3>");
            java.util.List<String> d = rb.reserve(name, request.getParameter("add"),
                    request.getParameter("ph"), request.getParameter("in"),
                    request.getParameter("out"), type, request.getParameter("mode"));
            out.println("<p>Name: " + d.get(0) + "<br/>Address: " + d.get(1) + "<br/>Phone: " + d.get(2)
                    + "<br/>Check-in: " + d.get(3) + "<br/>Check-out: " + d.get(4)
                    + "<br/>Room Type: " + d.get(5) + "<br/>Payment Mode: " + d.get(6) + "</p>");
            out.println("<h4>" + rb.payment(type) + "</h4>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
}


/* 06b_reservation.html
<!DOCTYPE html>
<html>
<head><title>Room Reservation</title></head>
<body>
  <h2>Room Reservation</h2>
  <form action="ReservationClient" method="post">
    Customer Name: <input name="cname"/><br/>
    Address: <input name="add"/><br/>
    Phone: <input name="ph"/><br/>
    Check-in: <input name="in" type="date"/><br/>
    Check-out: <input name="out" type="date"/><br/>
    Room Type: <select name="type"><option>SUITE</option><option>DELUXE</option><option>STANDARD</option></select><br/>
    Payment Mode: <select name="mode"><option>Cash</option><option>Card</option><option>UPI</option></select><br/>
    <input type="submit" value="Reserve"/>
  </form>
</body>
</html>
*/
