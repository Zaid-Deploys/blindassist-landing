/* 3(c) - Create a Servlet application demonstrating Non-Blocking Read Operation */

// 03c_AsyncUploadServlet.java
package ejpracts;

import java.io.IOException;
import javax.servlet.AsyncContext;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = "/AsyncUploadServlet", asyncSupported = true)
public class AsyncUploadServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        final AsyncContext ac = request.startAsync();
        ServletInputStream input = request.getInputStream();
        input.setReadListener(new MyReadListener(input, ac));
    }
}


// 03c_MyReadListener.java
package ejpracts;

import java.io.IOException;
import javax.servlet.AsyncContext;
import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;

class MyReadListener implements ReadListener {

    private final ServletInputStream iStream;
    private final AsyncContext ac;

    public MyReadListener(ServletInputStream in, AsyncContext ac) {
        this.iStream = in;
        this.ac = ac;
    }

    @Override
    public void onDataAvailable() {
        try {
            byte[] b = new byte[1024];
            int len;
            while (iStream.isReady() && (len = iStream.read(b)) != -1) {
                System.out.println("Read async: " + new String(b, 0, len));
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void onAllDataRead() {
        System.out.println("Non-blocking read complete.");
        ac.complete();
    }

    @Override
    public void onError(Throwable t) {
        t.printStackTrace();
        ac.complete();
    }
}


/* 03c_index.html
<!DOCTYPE html>
<html>
<head><title>Non-Blocking Read</title></head>
<body>
  <h2>Non-Blocking Read (Async)</h2>
  <p>Send a POST request to AsyncUploadServlet and watch the server log.</p>
  <form action="AsyncUploadServlet" method="post">
    <input name="data" value="Hello async"/>
    <input type="submit" value="Send"/>
  </form>
</body>
</html>
*/
