/* 8(b) - Develop a Guestbook Application using JPA */

// 08b_Guestbook.java
package myapp;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "guestbook")
public class Guestbook implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String visitorName;
    private String message;
    private String visitDate;

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getVisitorName() { return visitorName; }
    public void setVisitorName(String v) { this.visitorName = v; }
    public String getMessage() { return message; }
    public void setMessage(String m) { this.message = m; }
    public String getVisitDate() { return visitDate; }
    public void setVisitDate(String d) { this.visitDate = d; }
}


/* 08b_guestbook.jsp
<%@ page import="javax.persistence.*, myapp.Guestbook, java.util.List" contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%
   EntityManagerFactory emf = Persistence.createEntityManagerFactory("GUESTPU");
   EntityManager em = emf.createEntityManager();
   if (request.getParameter("sign") != null) {
     em.getTransaction().begin();
     Guestbook g = new Guestbook();
     g.setVisitorName(request.getParameter("vname"));
     g.setMessage(request.getParameter("msg"));
     g.setVisitDate(new java.util.Date().toString());
     em.persist(g);
     em.getTransaction().commit();
   }
   List<Guestbook> list = em.createQuery("SELECT g FROM Guestbook g", Guestbook.class).getResultList();
   request.setAttribute("entries", list);
   em.close();
   emf.close();
%>
<html><body>
<h2>Guestbook</h2>
<form method="post">
   Name: <input name="vname"/> Message: <input name="msg"/>
   <input type="submit" name="sign" value="Sign"/>
</form>
<c:forEach items="${entries}" var="e">
   <p><b>${e.visitorName}</b> (${e.visitDate}): ${e.message}</p>
</c:forEach>
</body></html>
*/

/* 08b_persistence.xml
<?xml version="1.0" encoding="UTF-8"?>
<persistence version="2.1" xmlns="http://xmlns.jcp.org/xml/ns/persistence">
  <persistence-unit name="GUESTPU" transaction-type="RESOURCE_LOCAL">
    <provider>org.eclipse.persistence.jpa.PersistenceProvider</provider>
    <class>myapp.Guestbook</class>
    <exclude-unlisted-classes>true</exclude-unlisted-classes>
    <properties>
      <property name="javax.persistence.jdbc.driver" value="com.mysql.cj.jdbc.Driver"/>
      <property name="javax.persistence.jdbc.url" value="jdbc:mysql://localhost:3306/reg?useSSL=false&amp;allowPublicKeyRetrieval=true&amp;serverTimezone=UTC"/>
      <property name="javax.persistence.jdbc.user" value="root"/>
      <property name="javax.persistence.jdbc.password" value="root"/>
      <property name="eclipselink.ddl-generation" value="create-or-extend-tables"/>
    </properties>
  </persistence-unit>
</persistence>
*/
