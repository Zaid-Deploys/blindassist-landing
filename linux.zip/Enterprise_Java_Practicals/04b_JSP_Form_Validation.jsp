<%-- 4(b) - Develop a JSP application to pass values between pages with validation --%>

<%-- 04b_form.html
<!DOCTYPE html>
<html>
<head><title>Form</title></head>
<body>
  <h2>Registration Form</h2>
  <form action="val.jsp" method="post">
    Full Name: <input name="fullname"/><br/>
    Age: <input name="age"/><br/>
    Email: <input name="email"/><br/>
    Gender: <input type="radio" name="gender" value="M"/>M
            <input type="radio" name="gender" value="F"/>F<br/>
    Hobbies: <input type="checkbox" name="hb" value="Reading"/>Reading
             <input type="checkbox" name="hb" value="Sports"/>Sports<br/>
    <input type="submit" value="Submit"/>
  </form>
</body>
</html>
--%>


<%-- 04b_val.jsp --%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%!
   private static final String EMAIL_REGEX = "^[\\w.+-]+@[\\w-]+\\.[a-zA-Z]{2,}$";
%>
<%
   String name = request.getParameter("fullname");
   String ageStr = request.getParameter("age");
   String email = request.getParameter("email");
   String gender = request.getParameter("gender");
   boolean hasError = false;
   int age = 0;
   if (name == null || name.trim().isEmpty() || email == null || email.trim().isEmpty()) {
     out.println("<p style='color:red;'>Please fill all required fields!</p>");
     hasError = true;
   }
   try {
     age = Integer.parseInt(ageStr);
     if (age < 18 || age > 60) {
       out.println("<p style='color:red;'>Age must be between 18 and 60.</p>");
       hasError = true;
     }
   } catch (NumberFormatException e) {
     out.println("<p style='color:red;'>Age must be numeric!</p>");
     hasError = true;
   }
   if (email != null && !email.matches(EMAIL_REGEX)) {
     out.println("<p style='color:red;'>Correct your email address format!</p>");
     hasError = true;
   }
   if (!hasError) {
     out.println("<h3>Registration Confirmed:</h3>");
     out.println("<p>Name: " + name + "<br/>Age: " + age + "<br/>Email: " + email
         + "<br/>Gender: " + gender + "</p>");
   }
%>
