<%-- 4(c) - Create a JSP registration and login application using JDBC --%>

<%-- 04c_dbLogin.jsp --%>
<%@ page contentType="text/html; charset=UTF-8" import="java.sql.*" %>
<%
   String userid = request.getParameter("uid");
   String pwd = request.getParameter("upass");
   String url = "jdbc:mysql://localhost:3306/reg?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
   try {
     Class.forName("com.mysql.cj.jdbc.Driver");
     try (Connection con = DriverManager.getConnection(url, "root", "root");
          PreparedStatement pst = con.prepareStatement("SELECT pwd FROM register WHERE uid=?")) {
       pst.setString(1, userid);
       try (ResultSet rs = pst.executeQuery()) {
         if (rs.next()) {
           if (rs.getString("pwd").equals(pwd)) {
             out.println("<h3 style='color:green;'>Login Successful, Welcome to JSP!</h3>");
           } else {
             out.println("<h3 style='color:red;'>Username or Password Wrong.</h3>");
             out.println("<a href='login.html'>Click here to Try Again</a>");
           }
         } else {
           out.println("<h3 style='color:red;'>User not found!</h3>");
         }
       }
     }
   } catch (Exception e) {
     out.println("<h3>Error: " + e.getMessage() + "</h3>");
   }
%>


<%-- 04c_login.html
<!DOCTYPE html>
<html>
<head><title>Login</title></head>
<body>
  <h2>Login</h2>
  <form action="dbLogin.jsp" method="post">
    User ID: <input name="uid"/><br/>
    Password: <input name="upass" type="password"/><br/>
    <input type="submit" value="Login"/>
  </form>
</body>
</html>
--%>
