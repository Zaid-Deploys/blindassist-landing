/* 1(a) - Create a simple calculator application using Servlet */

// 01a_Calculator.java
package ejpracts;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Calculator")
public class Calculator extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            try {
                double num1 = Double.parseDouble(request.getParameter("num1"));
                double num2 = Double.parseDouble(request.getParameter("num2"));
                String op = request.getParameter("operator");
                double result;
                switch (op) {
                    case "Addition":       result = num1 + num2; break;
                    case "Subtraction":    result = num1 - num2; break;
                    case "Multiplication": result = num1 * num2; break;
                    case "Division":
                        if (num2 == 0) { out.println("<h3>Cannot divide by zero!</h3>"); return; }
                        result = num1 / num2;
                        break;
                    default:
                        out.println("<h3>Unknown operator</h3>");
                        return;
                }
                out.println("<h3>" + op + " is: " + result + "</h3>");
            } catch (NumberFormatException e) {
                out.println("<h3>Please enter valid numbers.</h3>");
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
}


/* 01a_index.html
<!DOCTYPE html>
<html>
<head><title>Calculator Application</title></head>
<body>
  <h2>Simple Calculator</h2>
  <form action="Calculator" method="get">
    Enter Number 1: <input name="num1" type="text" required/><br/><br/>
    Enter Number 2: <input name="num2" type="text" required/><br/><br/>
    Operator:
    <select name="operator">
      <option value="Addition">Addition (+)</option>
      <option value="Subtraction">Subtraction (-)</option>
      <option value="Multiplication">Multiplication (*)</option>
      <option value="Division">Division (/)</option>
    </select><br/><br/>
    <input type="submit" value="Calculate"/>
  </form>
</body>
</html>
*/
