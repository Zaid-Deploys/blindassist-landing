/* 3(b) - Develop a Servlet Question Answer application using a database */

// 03b_Result.java
package ejpracts;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Result")
public class Result extends HttpServlet {

    private static final String URL =
        "jdbc:mysql://localhost:3306/reg?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            try (Connection con = DriverManager.getConnection(URL, "root", "root");
                 Statement stmt = con.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT ans FROM questions ORDER BY id")) {
                List<String> correct = new ArrayList<>();
                while (rs.next()) {
                    correct.add(rs.getString("ans"));
                }
                int count = 0;
                out.println("<b>Submitted Answers Review:</b><br/>");
                for (int i = 0; i < correct.size(); i++) {
                    String selected = request.getParameter("radio" + (i + 1));
                    boolean ok = selected != null && selected.equals(correct.get(i));
                    if (ok) {
                        count++;
                    }
                    out.println("<p style='color:" + (ok ? "green" : "red") + ";'>Q" + (i + 1) + ": "
                            + (selected == null ? "No answer" : selected)
                            + (ok ? " (Correct)" : " (Incorrect)") + "</p>");
                }
                out.println("<h3>Your <b>" + count + "</b> out of " + correct.size() + " answers are correct!</h3>");
            } catch (Exception e) {
                out.println("Error: " + e.getMessage());
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
}


/* 03b_database.sql
USE reg;
CREATE TABLE IF NOT EXISTS questions (
   id INT AUTO_INCREMENT PRIMARY KEY,
   ques VARCHAR(200), op1 VARCHAR(200), op2 VARCHAR(200),
   op3 VARCHAR(200), op4 VARCHAR(200), ans VARCHAR(200)
);
INSERT INTO questions (ques,op1,op2,op3,op4,ans) VALUES
('Capital of France?','Paris','Rome','Berlin','Madrid','Paris'),
('Which keyword creates an object in Java?','new','make','create','alloc','new'),
('Which package holds servlet classes?','javax.servlet','java.util','java.net','java.sql','javax.servlet');
*/


/* 03b_quiz.jsp
<%@ page import="java.sql.*" contentType="text/html; charset=UTF-8" %>
<html><body>
<h2>Online Quiz</h2>
<form action="Result" method="post">
<%
   Class.forName("com.mysql.cj.jdbc.Driver");
   String url = "jdbc:mysql://localhost:3306/reg?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
   try (Connection con = DriverManager.getConnection(url, "root", "root");
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM questions ORDER BY id")) {
     int n = 1;
     while (rs.next()) {
%>
   <p><b>Q<%= n %>. <%= rs.getString("ques") %></b><br/>
   <input type="radio" name="radio<%= n %>" value="<%= rs.getString("op1") %>"/> <%= rs.getString("op1") %><br/>
   <input type="radio" name="radio<%= n %>" value="<%= rs.getString("op2") %>"/> <%= rs.getString("op2") %><br/>
   <input type="radio" name="radio<%= n %>" value="<%= rs.getString("op3") %>"/> <%= rs.getString("op3") %><br/>
   <input type="radio" name="radio<%= n %>" value="<%= rs.getString("op4") %>"/> <%= rs.getString("op4") %></p>
<%
       n++;
     }
   }
%>
  <input type="submit" value="Submit Answers"/>
</form>
</body></html>
*/
