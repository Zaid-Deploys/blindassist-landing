<%-- 5(c) - Demonstrate JSTL in JSP --%>

<%-- 05c_jstlDemo.jsp --%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head><title>JSTL Core Demo</title></head>
<body>
  <p>First Name: <c:out value="${param.fname}"/><br/>
     Last Name: <c:out value="${param.lname}"/></p>

  <h4>c:set and c:if</h4>
  <c:set var="mycount" value="25"/>
  <c:if test="${mycount == 25}">
    <p>Your count is verified as: <c:out value="${mycount}"/></p>
  </c:if>

  <h4>c:forEach Iteration</h4>
  <c:forEach var="count" begin="101" end="105">
    <span>[<c:out value="${count}"/>]</span>
  </c:forEach>

  <h4>c:catch Exception Handling</h4>
  <c:catch var="myException">
    <% int number = 10 / 0; %>
  </c:catch>
  <p style="color:red;">Handled Exception: <b>${myException.message}</b></p>
</body>
</html>
