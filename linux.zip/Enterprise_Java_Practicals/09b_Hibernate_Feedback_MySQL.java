/* 9(b) - Develop a Hibernate application to store website visitor feedback in MySQL */

// 09b_Feedback.java
package hibapp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "feedback")
public class Feedback {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "visitor_name")
    private String visitorName;

    private String email;
    private String message;

    public Feedback() {
    }

    public Feedback(String visitorName, String email, String message) {
        this.visitorName = visitorName;
        this.email = email;
        this.message = message;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getVisitorName() { return visitorName; }
    public void setVisitorName(String visitorName) { this.visitorName = visitorName; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}


// 09b_FeedbackApp.java
package hibapp;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

class FeedbackApp {

    public static void main(String[] args) {
        SessionFactory factory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Feedback.class)
                .buildSessionFactory();

        // Save one feedback row
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        Feedback f = new Feedback("Rahul Sharma", "rahul@example.com", "Very informative website!");
        session.save(f);
        tx.commit();
        System.out.println("Feedback saved with id: " + f.getId());
        session.close();

        // Retrieve and list all feedback
        Session session2 = factory.openSession();
        List<Feedback> list = session2.createQuery("from Feedback", Feedback.class).list();
        System.out.println("--- All Website Feedback ---");
        for (Feedback fb : list) {
            System.out.println(fb.getId() + " | " + fb.getVisitorName() + " | " + fb.getEmail() + " | " + fb.getMessage());
        }
        session2.close();
        factory.close();
    }
}


/* 09b_hibernate.cfg.xml
<!DOCTYPE hibernate-configuration PUBLIC
  "-//Hibernate/Hibernate Configuration DTD 3.0//EN"
  "http://www.hibernate.org/dtd/hibernate-configuration-3.0.dtd">
<hibernate-configuration>
  <session-factory>
    <property name="hibernate.connection.driver_class">com.mysql.cj.jdbc.Driver</property>
    <property name="hibernate.connection.url">jdbc:mysql://localhost:3306/reg?useSSL=false&amp;allowPublicKeyRetrieval=true&amp;serverTimezone=UTC</property>
    <property name="hibernate.connection.username">root</property>
    <property name="hibernate.connection.password">root</property>
    <property name="hibernate.dialect">org.hibernate.dialect.MySQL8Dialect</property>
    <property name="hibernate.hbm2ddl.auto">update</property>
    <property name="hibernate.show_sql">true</property>
  </session-factory>
</hibernate-configuration>
*/


/* 09b_pom.xml
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>
  <groupId>com.ejava</groupId>
  <artifactId>hibernate-practical</artifactId>
  <version>1.0</version>
  <properties>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    <maven.compiler.source>8</maven.compiler.source>
    <maven.compiler.target>8</maven.compiler.target>
  </properties>
  <dependencies>
    <dependency>
      <groupId>org.hibernate</groupId>
      <artifactId>hibernate-core</artifactId>
      <version>5.6.15.Final</version>
    </dependency>
    <dependency>
      <groupId>mysql</groupId>
      <artifactId>mysql-connector-java</artifactId>
      <version>8.0.33</version>
    </dependency>
  </dependencies>
</project>
*/
